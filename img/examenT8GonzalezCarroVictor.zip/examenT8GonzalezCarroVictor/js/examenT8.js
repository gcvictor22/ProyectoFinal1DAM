function pedirNombres() {
    let nombres = [];
    let cant = 1;


    for (let i = 0; i < cant; i++) {
        let add = prompt('Introduce un nombre cualquiera:');
        do {
            nombres[i] = add;
            cant++;
        } while (nombres[i]>=0);
    }
}

function camelize(str) {
    let arr = str.split("-");
    let palabras = [];

    for (let i = 0; i < arr.length; i++) {
        palabras[i] = arr[i].charAt(0).toUpperCase() + arr[i];
    }
    let frase = palabras.join('');
    alert(frase);
}

function sortear() {
    let arr = [1, 2, 3, 4, 5];

    let ale = Math.random() * (arr.length - 1);
    let truncado = Math.trunc(ale);

    alert(arr[truncado]);
}